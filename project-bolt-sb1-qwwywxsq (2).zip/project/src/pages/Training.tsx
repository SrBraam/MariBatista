import React from "react";
import Courses from "../components/Courses";

export default function Training() {
  return (
    <div>
      <Courses viewMode="blocks" />
    </div>
  );
}
